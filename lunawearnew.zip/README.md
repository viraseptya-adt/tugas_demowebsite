# LunaWear — Sistem Informasi Penjualan & Stok Toko

## Struktur
- index.html
- style.css
- script.js

## Menjalankan
1. Simpan ketiga file dalam satu folder.
2. Buka `index.html` di browser modern (Chrome/Edge/Firefox).
3. Login demo:
   - Username: `admin`
   - Password: `admin123`

Tidak membutuhkan backend, npm, atau database eksternal.

## Fitur
- Login/logout admin dengan status login di localStorage.
- Dashboard statistik omzet, produk, pelanggan, stok menipis.
- Grafik penjualan 7 hari menggunakan Canvas API.
- CRUD produk + pencarian + filter kategori/stok.
- Transaksi dengan keranjang, validasi pembayaran, kembalian, dan pengurangan stok otomatis.
- CRUD pelanggan.
- Laporan penjualan dengan filter tanggal/metode pembayaran dan cetak.
- Data contoh fashion realistis.
- Semua data tersimpan di localStorage.

## Pengujian
- [x] Login benar/salah.
- [x] Logout dan login ulang.
- [x] Reload halaman mempertahankan data.
- [x] Tambah/edit/hapus produk.
- [x] Validasi harga positif dan stok tidak negatif.
- [x] Pencarian/filter produk.
- [x] Tambah produk ke keranjang.
- [x] Kuantitas tidak boleh melebihi stok.
- [x] Transaksi tunai menolak pembayaran kurang.
- [x] Kembalian dihitung otomatis.
- [x] Transaksi mengurangi stok.
- [x] CRUD pelanggan.
- [x] Filter laporan.
- [x] Cetak laporan.
- [x] Responsive mobile/tablet/desktop.

## Catatan
Versi ini sengaja dibuat tanpa framework agar mudah dipelajari dan dipresentasikan dalam tugas Vibe Coding Web. Data dapat di-reset dengan menghapus site data/localStorage browser untuk halaman ini.

## Tema Data Contoh
Produk contoh telah diganti menjadi pakaian dan aksesori fashion: kaos, kemeja, rok, celana, dress, outerwear, tas, dan aksesori.


## Tema UI terbaru
Tema diubah agar tidak sama dengan versi sebelumnya: **emerald green + cream + charcoal + gold accent**. Gaya visualnya lebih editorial/contemporary fashion, bukan pastel pink-lavender.
