(() => {
"use strict";

const KEY = "lunawear_fashion_data_v1";
const LOGIN_KEY = "lunawear_logged_in";
const demoProducts = [
  {id:"P001",name:"Luna Basic Oversized T-Shirt",category:"Kaos",price:89000,stock:18},
  {id:"P002",name:"Aster Linen Shirt",category:"Kemeja",price:179000,stock:10},
  {id:"P003",name:"Mila Pleated Skirt",category:"Rok",price:159000,stock:12},
  {id:"P004",name:"Nora Wide Leg Jeans",category:"Celana",price:249000,stock:7},
  {id:"P005",name:"Sora Knit Cardigan",category:"Outerwear",price:199000,stock:4},
  {id:"P006",name:"Ayla Midi Dress",category:"Dress",price:229000,stock:3},
  {id:"P007",name:"Rhea Shoulder Bag",category:"Tas",price:189000,stock:9},
  {id:"P008",name:"Kira Basic Hijab",category:"Aksesori",price:69000,stock:20}
];
const demoCustomers = [
  {id:"C001",name:"Alya Putri",phone:"081234567890",email:"alya@example.com"},
  {id:"C002",name:"Nadia Rahma",phone:"082112223333",email:"nadia@example.com"},
  {id:"C003",name:"Salsa Maharani",phone:"085612345678",email:"salsa@example.com"}
];

let data = loadData();
let cart = [];
let currentSection = "dashboard";
let salesChartInstance = null;

function seedTransactions(){
  const now = new Date();
  const d = (daysAgo) => {
    const x = new Date(now); x.setDate(x.getDate()-daysAgo); x.setHours(12,0,0,0); return x.toISOString();
  };
  return [
    {id:"TRX-1001",date:d(0),customerId:"C001",payment:"QRIS",items:[{productId:"P003",qty:1,price:159000}],total:159000},
    {id:"TRX-1002",date:d(1),customerId:"C002",payment:"Tunai",items:[{productId:"P001",qty:1,price:89000},{productId:"P005",qty:1,price:199000}],total:288000},
    {id:"TRX-1003",date:d(2),customerId:"C003",payment:"Transfer",items:[{productId:"P007",qty:2,price:189000}],total:378000},
    {id:"TRX-1004",date:d(3),customerId:"",payment:"QRIS",items:[{productId:"P002",qty:1,price:179000}],total:179000},
    {id:"TRX-1005",date:d(4),customerId:"C001",payment:"Tunai",items:[{productId:"P006",qty:1,price:229000}],total:229000}
  ];
}
function loadData(){
  try{
    const raw=localStorage.getItem(KEY);
    if(raw){
      const parsed=JSON.parse(raw);
      return {products:parsed.products||demoProducts,customers:parsed.customers||demoCustomers,transactions:parsed.transactions||[]};
    }
  }catch(e){ console.warn("Data localStorage rusak, memakai data awal.",e); }
  return {products:demoProducts,customers:demoCustomers,transactions:seedTransactions()};
}
function saveData(){localStorage.setItem(KEY,JSON.stringify(data));}
function rupiah(n){return new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(Number(n)||0)}
function dateID(value){return new Intl.DateTimeFormat("id-ID",{day:"2-digit",month:"short",year:"numeric"}).format(new Date(value))}
function dateInput(value){const d=new Date(value); return new Intl.DateTimeFormat("en-CA").format(d)}
function esc(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function uid(prefix){return prefix+Date.now().toString(36).slice(-6).toUpperCase()}
function customerName(id){return data.customers.find(c=>c.id===id)?.name || "Pelanggan Umum"}
function productById(id){return data.products.find(p=>p.id===id)}

const $=sel=>document.querySelector(sel);
const $$=sel=>[...document.querySelectorAll(sel)];

function showToast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");clearTimeout(showToast.timer);showToast.timer=setTimeout(()=>t.classList.remove("show"),2500)}
function openModal(html){$("#modal").innerHTML=html;$("#modalOverlay").classList.remove("hidden")}
function closeModal(){$("#modalOverlay").classList.add("hidden");$("#modal").innerHTML=""}

function init(){
  $("#todayLabel").textContent=new Intl.DateTimeFormat("id-ID",{weekday:"long",day:"numeric",month:"long",year:"numeric"}).format(new Date());
  $("#loginForm").addEventListener("submit",login);
  $("#logoutBtn").addEventListener("click",logout);
  $$(".nav-item[data-section]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.section)));
  $$("[data-go]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.go)));
  $$("[data-section-link]").forEach(b=>b.addEventListener("click",()=>navigate(b.dataset.sectionLink)));
  $("#mobileMenuBtn").addEventListener("click",()=>$(".sidebar").classList.toggle("open"));
  $("#modalOverlay").addEventListener("click",e=>{if(e.target.id==="modalOverlay")closeModal()});
  $("#addProductBtn").addEventListener("click",()=>productModal());
  $("#addCustomerBtn").addEventListener("click",()=>customerModal());
  $("#productSearch").addEventListener("input",renderProducts);
  $("#productCategoryFilter").addEventListener("change",renderProducts);
  $("#productStockFilter").addEventListener("change",renderProducts);
  $("#transactionSearch").addEventListener("input",renderTransactionProducts);
  $("#transactionCustomer").addEventListener("change",renderCart);
  $("#paymentMethod").addEventListener("change",renderCart);
  $("#cashPaid").addEventListener("input",renderCart);
  $("#completeTransactionBtn").addEventListener("click",completeTransaction);
  $("#printReportBtn").addEventListener("click",printReport);
  $("#resetReportBtn").addEventListener("click",()=>{ $("#reportStart").value="";$("#reportEnd").value="";$("#reportPayment").value="";renderReports(); });
  ["#reportStart","#reportEnd","#reportPayment"].forEach(s=>$(s).addEventListener("change",renderReports));
  if(localStorage.getItem(LOGIN_KEY)==="1") enterApp(); else $("#loginPage").classList.remove("hidden");
}

function login(e){
  e.preventDefault();
  const u=$("#loginUsername").value.trim(),p=$("#loginPassword").value;
  if((u==="admin"||u==="admin@glowstock.local")&&p==="admin123"){localStorage.setItem(LOGIN_KEY,"1");$("#loginError").textContent="";enterApp()}
  else $("#loginError").textContent="Username atau password salah. Gunakan demo: admin / admin123.";
}
function enterApp(){ $("#loginPage").classList.add("hidden");$("#app").classList.remove("hidden");navigate(currentSection); }
function logout(){localStorage.removeItem(LOGIN_KEY);cart=[];$("#app").classList.add("hidden");$("#loginPage").classList.remove("hidden");$("#loginPassword").value="";showToast("Anda telah logout.");}
function navigate(section){
  currentSection=section;
  $$(".page-section").forEach(s=>s.classList.toggle("active",s.id===section+"Section"));
  $$(".nav-item[data-section]").forEach(b=>b.classList.toggle("active",b.dataset.section===section));
  const titles={dashboard:"Dashboard",products:"Produk",transactions:"Transaksi Penjualan",customers:"Pelanggan",reports:"Laporan Penjualan"};
  $("#pageTitle").textContent=titles[section]||"Dashboard";
  $(".sidebar").classList.remove("open");
  if(section==="dashboard")renderDashboard();
  if(section==="products")renderProducts();
  if(section==="transactions"){populateCustomerSelect();renderTransactionProducts();renderCart();}
  if(section==="customers")renderCustomers();
  if(section==="reports")renderReports();
}

function renderDashboard(){
  const revenue=data.transactions.reduce((a,t)=>a+t.total,0);
  const stock=data.products.reduce((a,p)=>a+p.stock,0);
  const low=data.products.filter(p=>p.stock<=5).length;
  $("#statSales").textContent=rupiah(revenue);
  $("#statSalesMeta").textContent=`${data.transactions.length} transaksi`;
  $("#statProducts").textContent=data.products.length;
  $("#statProductsMeta").textContent=`${stock} unit stok tersedia`;
  $("#statCustomers").textContent=data.customers.length;
  $("#statLowStock").textContent=low;
  const sold={};
  data.transactions.forEach(t=>t.items.forEach(i=>sold[i.productId]=(sold[i.productId]||0)+i.qty));
  const top=Object.entries(sold).sort((a,b)=>b[1]-a[1]).slice(0,5);
  $("#topProducts").innerHTML=top.length?top.map(([id,q],i)=>{const p=productById(id);return `<div class="rank-item"><span class="rank-no">${i+1}</span><div><strong>${esc(p?.name||"Produk dihapus")}</strong><small>${q} item terjual</small></div><span class="rank-value">${rupiah((p?.price||0)*q)}</span></div>`}).join(""):`<div class="empty-state">Belum ada data penjualan.</div>`;
  const recent=[...data.transactions].sort((a,b)=>new Date(b.date)-new Date(a.date)).slice(0,5);
  $("#recentTransactions").innerHTML=recent.length?recent.map(t=>`<tr><td><strong>${t.id}</strong></td><td>${dateID(t.date)}</td><td>${esc(customerName(t.customerId))}</td><td><strong>${rupiah(t.total)}</strong></td><td><span class="badge success">Selesai</span></td></tr>`).join(""):`<tr><td colspan="5" class="empty-state">Belum ada transaksi.</td></tr>`;
  drawChart();
}
function drawChart(){
  const canvas=$("#salesChart");const ctx=canvas.getContext("2d");const rect=canvas.getBoundingClientRect();const dpr=window.devicePixelRatio||1;
  canvas.width=rect.width*dpr;canvas.height=rect.height*dpr;ctx.scale(dpr,dpr);
  const w=rect.width,h=rect.height;ctx.clearRect(0,0,w,h);
  const labels=[],vals=[];
  for(let i=6;i>=0;i--){const d=new Date();d.setHours(0,0,0,0);d.setDate(d.getDate()-i);labels.push(new Intl.DateTimeFormat("id-ID",{weekday:"short"}).format(d));const key=d.toDateString();vals.push(data.transactions.filter(t=>new Date(t.date).toDateString()===key).reduce((a,t)=>a+t.total,0))}
  const max=Math.max(...vals,100000),left=45,bottom=30,top=12,right=10,chartH=h-top-bottom,chartW=w-left-right;
  ctx.font="10px Inter";ctx.textAlign="right";ctx.fillStyle="#a09aa8";for(let i=0;i<=4;i++){const y=top+chartH-(chartH*i/4);ctx.fillText(rupiah(max*i/4).replace("Rp",""),left-7,y+3);ctx.strokeStyle="#f0edf2";ctx.beginPath();ctx.moveTo(left,y);ctx.lineTo(w-right,y);ctx.stroke()}
  const pts=vals.map((v,i)=>[left+(chartW*i/6),top+chartH-(v/max)*chartH]);ctx.strokeStyle="#8068bd";ctx.lineWidth=3;ctx.beginPath();pts.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.stroke();
  pts.forEach((p,i)=>{ctx.fillStyle="#fff";ctx.beginPath();ctx.arc(p[0],p[1],5,0,Math.PI*2);ctx.fill();ctx.strokeStyle="#d979a2";ctx.lineWidth=3;ctx.stroke();ctx.fillStyle="#7f7886";ctx.textAlign="center";ctx.font="10px Inter";ctx.fillText(labels[i],p[0],h-8)});
}

function categoryOptions(){
  const cats=[...new Set(data.products.map(p=>p.category))].sort();
  $("#productCategoryFilter").innerHTML=`<option value="">Semua Kategori</option>`+cats.map(c=>`<option>${esc(c)}</option>`).join("");
}
function renderProducts(){
  categoryOptions();
  const q=$("#productSearch").value.toLowerCase(),cat=$("#productCategoryFilter").value,stockFilter=$("#productStockFilter").value;
  let arr=data.products.filter(p=>(!q||`${p.name} ${p.category}`.toLowerCase().includes(q))&&(!cat||p.category===cat));
  if(stockFilter==="low")arr=arr.filter(p=>p.stock>0&&p.stock<=5);if(stockFilter==="empty")arr=arr.filter(p=>p.stock===0);if(stockFilter==="available")arr=arr.filter(p=>p.stock>0);
  $("#productsTable").innerHTML=arr.length?arr.map(p=>`<tr><td><div class="product-name"><span class="product-thumb">✦</span><div><strong>${esc(p.name)}</strong><small class="muted">${p.id}</small></div></div></td><td>${esc(p.category)}</td><td><strong>${rupiah(p.price)}</strong></td><td>${p.stock}</td><td>${stockBadge(p.stock)}</td><td><button class="action-btn edit" data-edit-product="${p.id}">Edit</button><button class="action-btn delete" data-delete-product="${p.id}">Hapus</button></td></tr>`).join(""):`<tr><td colspan="6" class="empty-state">Produk tidak ditemukan.</td></tr>`;
  $$("[data-edit-product]").forEach(b=>b.onclick=()=>productModal(b.dataset.editProduct));$$("[data-delete-product]").forEach(b=>b.onclick=()=>deleteProduct(b.dataset.deleteProduct));
}
function stockBadge(s){return s===0?'<span class="badge danger">Habis</span>':s<=5?'<span class="badge warning">Menipis</span>':'<span class="badge success">Tersedia</span>'}

function productModal(id){
  const p=id?productById(id):{id:uid("P"),name:"",category:"Serum",price:"",stock:""};
  openModal(`<div class="modal-header"><div><h3>${id?"Edit Produk":"Tambah Produk"}</h3><p class="muted">Lengkapi data produk fashion.</p></div><button class="close-modal" onclick="closeModal()">×</button></div>
  <form id="productForm" class="modal-form"><label>Nama Produk<input id="mProductName" required maxlength="80" value="${esc(p.name)}"></label>
  <label>Kategori<select id="mProductCategory">${["Kaos","Kemeja","Celana","Rok","Dress","Outerwear","Tas","Aksesori"].map(c=>`<option ${p.category===c?"selected":""}>${c}</option>`).join("")}</select></label>
  <div class="form-grid"><label>Harga (Rp)<input id="mProductPrice" type="number" min="1" step="100" required value="${p.price}"></label><label>Stok<input id="mProductStock" type="number" min="0" step="1" required value="${p.stock}"></label></div>
  <div class="modal-actions"><button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button><button class="btn btn-primary">Simpan</button></div><p id="modalError" class="form-error"></p></form>`);
  $("#productForm").onsubmit=e=>{e.preventDefault();const name=$("#mProductName").value.trim(),price=Number($("#mProductPrice").value),stock=Number($("#mProductStock").value);if(!name||price<=0||stock<0||!Number.isInteger(stock)){ $("#modalError").textContent="Pastikan nama, harga, dan stok valid.";return} if(id){Object.assign(p,{name,category:$("#mProductCategory").value,price,stock})}else data.products.push({id:p.id,name,category:$("#mProductCategory").value,price,stock});saveData();closeModal();renderProducts();renderDashboard();renderTransactionProducts();showToast(id?"Produk diperbarui.":"Produk ditambahkan.")};
}
function deleteProduct(id){const p=productById(id);if(!p)return;if(data.transactions.some(t=>t.items.some(i=>i.productId===id))){showToast("Produk yang sudah pernah ditransaksikan tidak dapat dihapus.");return}if(confirm(`Hapus produk "${p.name}"?`)){data.products=data.products.filter(x=>x.id!==id);saveData();renderProducts();renderDashboard();renderTransactionProducts();showToast("Produk dihapus.")}}

function populateCustomerSelect(){
  $("#transactionCustomer").innerHTML='<option value="">Pelanggan Umum</option>'+data.customers.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join("");
}
function renderTransactionProducts(){
  const q=$("#transactionSearch").value.toLowerCase();
  const arr=data.products.filter(p=>!q||`${p.name} ${p.category}`.toLowerCase().includes(q));
  $("#transactionProducts").innerHTML=arr.map(p=>`<div class="picker-card"><strong>${esc(p.name)}</strong><small>${esc(p.category)} • ${rupiah(p.price)} • Stok ${p.stock}</small><button ${p.stock===0?"disabled":""} data-add-cart="${p.id}">${p.stock===0?"Stok Habis":"Tambah ke Keranjang"}</button></div>`).join("");
  $$("[data-add-cart]").forEach(b=>b.onclick=()=>addToCart(b.dataset.addCart));
}
function addToCart(id){const p=productById(id);if(!p||p.stock<=0)return;const item=cart.find(i=>i.productId===id);if(item){if(item.qty>=p.stock){showToast("Jumlah melebihi stok tersedia.");return}item.qty++}else cart.push({productId:id,qty:1});renderCart();showToast("Produk ditambahkan ke keranjang.")}
function changeQty(id,delta){const item=cart.find(i=>i.productId===id),p=productById(id);if(!item||!p)return;item.qty=Math.max(0,Math.min(p.stock,item.qty+delta));if(item.qty===0)cart=cart.filter(i=>i.productId!==id);renderCart();}
function removeCart(id){cart=cart.filter(i=>i.productId!==id);renderCart()}
function renderCart(){
  const total=cart.reduce((a,i)=>a+(productById(i.productId)?.price||0)*i.qty,0);
  $("#cartCount").textContent=`${cart.reduce((a,i)=>a+i.qty,0)} item`;
  $("#cartEmpty").classList.toggle("hidden",cart.length>0);
  $("#cartList").innerHTML=cart.map(i=>{const p=productById(i.productId);return `<div class="cart-item"><div><strong>${esc(p.name)}</strong><small>${rupiah(p.price)} × ${i.qty}</small></div><div class="qty-control"><button onclick="changeQty('${p.id}',-1)">−</button><strong>${i.qty}</strong><button onclick="changeQty('${p.id}',1)">+</button></div><button class="action-btn delete" onclick="removeCart('${p.id}')">Hapus</button></div>`}).join("");
  $("#cartSubtotal").textContent=rupiah(total);$("#cartTotal").textContent=rupiah(total);
  const paid=Number($("#cashPaid").value)||0;$("#changeAmount").textContent=rupiah(Math.max(0,paid-total));
}
function completeTransaction(){
  const err=$("#transactionError");err.textContent="";
  if(!cart.length){err.textContent="Keranjang masih kosong.";return}
  const total=cart.reduce((a,i)=>a+(productById(i.productId)?.price||0)*i.qty,0),method=$("#paymentMethod").value,paid=Number($("#cashPaid").value)||0;
  if(method==="Tunai"&&paid<total){err.textContent=`Uang dibayar kurang ${rupiah(total-paid)}.`;return}
  for(const i of cart){const p=productById(i.productId);if(!p||p.stock<i.qty){err.textContent=`Stok ${p?.name||"produk"} tidak mencukupi.`;return}}
  const trx={id:uid("TRX-"),date:new Date().toISOString(),customerId:$("#transactionCustomer").value,payment:method,items:cart.map(i=>{const p=productById(i.productId);return {productId:p.id,qty:i.qty,price:p.price}}),total};
  cart.forEach(i=>productById(i.productId).stock-=i.qty);data.transactions.push(trx);saveData();
  cart=[];$("#cashPaid").value="";renderCart();renderTransactionProducts();renderDashboard();showToast(`Transaksi ${trx.id} berhasil disimpan.`);
}

function renderCustomers(){
  $("#customersTable").innerHTML=data.customers.map(c=>{const spent=data.transactions.filter(t=>t.customerId===c.id).reduce((a,t)=>a+t.total,0);return `<tr><td><strong>${esc(c.name)}</strong><small class="muted">${c.id}</small></td><td>${esc(c.phone)}</td><td>${esc(c.email)}</td><td><strong>${rupiah(spent)}</strong></td><td><button class="action-btn edit" data-edit-customer="${c.id}">Edit</button><button class="action-btn delete" data-delete-customer="${c.id}">Hapus</button></td></tr>`}).join("")||`<tr><td colspan="5" class="empty-state">Belum ada pelanggan.</td></tr>`;
  $$("[data-edit-customer]").forEach(b=>b.onclick=()=>customerModal(b.dataset.editCustomer));$$("[data-delete-customer]").forEach(b=>b.onclick=()=>deleteCustomer(b.dataset.deleteCustomer));
}
function customerModal(id){
  const c=id?data.customers.find(x=>x.id===id):{id:uid("C"),name:"",phone:"",email:""};
  openModal(`<div class="modal-header"><div><h3>${id?"Edit Pelanggan":"Tambah Pelanggan"}</h3><p class="muted">Data digunakan saat transaksi.</p></div><button class="close-modal" onclick="closeModal()">×</button></div>
  <form id="customerForm" class="modal-form"><label>Nama Lengkap<input id="mCustomerName" required maxlength="60" value="${esc(c.name)}"></label><label>No. Telepon<input id="mCustomerPhone" required pattern="[0-9+ -]{8,18}" value="${esc(c.phone)}"></label><label>Email<input id="mCustomerEmail" type="email" required value="${esc(c.email)}"></label><div class="modal-actions"><button type="button" class="btn btn-ghost" onclick="closeModal()">Batal</button><button class="btn btn-primary">Simpan</button></div><p id="modalError" class="form-error"></p></form>`);
  $("#customerForm").onsubmit=e=>{e.preventDefault();const name=$("#mCustomerName").value.trim(),phone=$("#mCustomerPhone").value.trim(),email=$("#mCustomerEmail").value.trim();if(name.length<2||!/^[0-9+ -]{8,18}$/.test(phone)||!email.includes("@")){$("#modalError").textContent="Data pelanggan belum valid.";return}if(id)Object.assign(c,{name,phone,email});else data.customers.push({id:c.id,name,phone,email});saveData();closeModal();renderCustomers();populateCustomerSelect();renderDashboard();showToast(id?"Pelanggan diperbarui.":"Pelanggan ditambahkan.")};
}
function deleteCustomer(id){if(data.transactions.some(t=>t.customerId===id)){showToast("Pelanggan yang sudah memiliki transaksi tidak dapat dihapus.");return}if(confirm("Hapus pelanggan ini?")){data.customers=data.customers.filter(c=>c.id!==id);saveData();renderCustomers();populateCustomerSelect();showToast("Pelanggan dihapus.")}}

function filteredTransactions(){
  const start=$("#reportStart").value,end=$("#reportEnd").value,pay=$("#reportPayment").value;
  return data.transactions.filter(t=>{const d=dateInput(t.date);return(!start||d>=start)&&(!end||d<=end)&&(!pay||t.payment===pay)}).sort((a,b)=>new Date(b.date)-new Date(a.date));
}
function renderReports(){
  const arr=filteredTransactions(),revenue=arr.reduce((a,t)=>a+t.total,0),items=arr.reduce((a,t)=>a+t.items.reduce((x,i)=>x+i.qty,0),0);
  $("#reportRevenue").textContent=rupiah(revenue);$("#reportCount").textContent=arr.length;$("#reportItems").textContent=items;
  $("#reportsTable").innerHTML=arr.length?arr.map(t=>`<tr><td><strong>${t.id}</strong></td><td>${dateID(t.date)}</td><td>${esc(customerName(t.customerId))}</td><td>${t.items.reduce((a,i)=>a+i.qty,0)}</td><td>${esc(t.payment)}</td><td><strong>${rupiah(t.total)}</strong></td></tr>`).join(""):`<tr><td colspan="6" class="empty-state">Tidak ada transaksi pada filter tersebut.</td></tr>`;
}
function printReport(){
  if(!filteredTransactions().length){showToast("Tidak ada data untuk dicetak.");return}
  const old=document.title;document.title="Laporan Penjualan LunaWear";window.print();setTimeout(()=>document.title=old,500);
}

window.closeModal=closeModal;window.changeQty=changeQty;window.removeCart=removeCart;
window.addEventListener("resize",()=>{if(currentSection==="dashboard")drawChart()});
document.addEventListener("DOMContentLoaded",init);
})();